import Link from "next/link";
import { Header } from "@/components/Header";
import { prisma } from "@/lib/prisma";

function formatarMoeda(valor: unknown) {
  return Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

const rotulosStatus: Record<string, { texto: string; classe: string }> = {
  rascunho: { texto: "Rascunho", classe: "bg-neutral-200 text-neutral-600" },
  enviada: { texto: "Enviada", classe: "bg-blue-100 text-blue-700" },
  autorizada: { texto: "Autorizada", classe: "bg-green-100 text-green-700" },
  rejeitada: { texto: "Rejeitada", classe: "bg-red-100 text-red-700" },
  cancelada: { texto: "Cancelada", classe: "bg-neutral-200 text-neutral-500" },
};

export default async function NotasFiscaisPage() {
  const notas = await prisma.notaFiscal.findMany({
    include: { cliente: true },
    orderBy: { criadoEm: "desc" },
  });

  return (
    <>
      <Header title="Notas fiscais" />
      <div className="p-8">
        <p className="mb-4 text-sm text-neutral-500">
          Notas são geradas a partir de uma ordem de manutenção concluída (veja o botão
          &quot;Gerar nota fiscal&quot; na tela da ordem).
        </p>

        <div className="overflow-hidden rounded-lg border border-neutral-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-neutral-50 text-neutral-500">
              <tr>
                <th className="px-4 py-3 font-medium">Cliente</th>
                <th className="px-4 py-3 font-medium">Tipo</th>
                <th className="px-4 py-3 font-medium">Valor total</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Criada em</th>
              </tr>
            </thead>
            <tbody>
              {notas.map((nota) => {
                const status = rotulosStatus[nota.status];
                return (
                  <tr key={nota.id} className="border-t border-neutral-100">
                    <td className="px-4 py-3">
                      <Link
                        href={`/notas-fiscais/${nota.id}`}
                        className="text-neutral-900 hover:underline"
                      >
                        {nota.cliente.nomeRazaoSocial}
                      </Link>
                    </td>
                    <td className="px-4 py-3 uppercase text-neutral-600">{nota.tipo}</td>
                    <td className="px-4 py-3 text-neutral-600">
                      {formatarMoeda(nota.valorTotal)}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${status.classe}`}>
                        {status.texto}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-neutral-600">
                      {nota.criadoEm.toLocaleDateString("pt-BR")}
                    </td>
                  </tr>
                );
              })}
              {notas.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-neutral-400">
                    Nenhuma nota fiscal gerada ainda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
