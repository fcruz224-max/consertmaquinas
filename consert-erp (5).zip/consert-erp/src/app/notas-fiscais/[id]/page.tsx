import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { EnviarNotaButton } from "@/components/EnviarNotaButton";
import { prisma } from "@/lib/prisma";

function formatarMoeda(valor: unknown) {
  return Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export default async function DetalheNotaFiscalPage({
  params,
}: {
  params: { id: string };
}) {
  const nota = await prisma.notaFiscal.findUnique({
    where: { id: Number(params.id) },
    include: { cliente: true, itens: true, ordemManutencao: true },
  });

  if (!nota) {
    notFound();
  }

  return (
    <>
      <Header title={`Nota fiscal — ${nota.cliente.nomeRazaoSocial}`} />
      <div className="grid grid-cols-3 gap-6 p-8">
        <div className="col-span-2 space-y-6">
          <div className="rounded-lg border border-neutral-200 bg-white p-5">
            <h2 className="mb-3 text-sm font-medium text-neutral-500">Itens da nota</h2>
            <table className="w-full text-left text-sm">
              <thead className="bg-neutral-50 text-neutral-500">
                <tr>
                  <th className="px-3 py-2 font-medium">Descrição</th>
                  <th className="px-3 py-2 font-medium">Qtd.</th>
                  <th className="px-3 py-2 font-medium">Valor unit.</th>
                  <th className="px-3 py-2 font-medium">Total</th>
                </tr>
              </thead>
              <tbody>
                {nota.itens.map((item) => (
                  <tr key={item.id} className="border-t border-neutral-100">
                    <td className="px-3 py-2 text-neutral-800">{item.descricao}</td>
                    <td className="px-3 py-2 text-neutral-600">{Number(item.quantidade)}</td>
                    <td className="px-3 py-2 text-neutral-600">
                      {formatarMoeda(item.valorUnitario)}
                    </td>
                    <td className="px-3 py-2 text-neutral-600">
                      {formatarMoeda(item.valorTotal)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {nota.status === "rascunho" && (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-5">
              <p className="mb-3 text-sm text-amber-800">
                Esta nota ainda é um rascunho interno — nada foi enviado à SEFAZ.
                O envio só funciona depois que um provedor de NF-e for configurado
                (veja o README do projeto).
              </p>
              <EnviarNotaButton notaId={nota.id} />
            </div>
          )}
        </div>

        <div className="space-y-4 rounded-lg border border-neutral-200 bg-white p-5 text-sm">
          <div>
            <p className="text-neutral-500">Cliente</p>
            <p className="text-neutral-900">{nota.cliente.nomeRazaoSocial}</p>
          </div>
          <div>
            <p className="text-neutral-500">Ordem de manutenção de origem</p>
            <p className="text-neutral-900">{nota.ordemManutencao?.numero ?? "—"}</p>
          </div>
          <div>
            <p className="text-neutral-500">Valor total</p>
            <p className="text-lg font-medium text-neutral-900">
              {formatarMoeda(nota.valorTotal)}
            </p>
          </div>
          <div>
            <p className="text-neutral-500">Status</p>
            <p className="text-neutral-900">{nota.status}</p>
          </div>
        </div>
      </div>
    </>
  );
}
