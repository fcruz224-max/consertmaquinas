import { Header } from "@/components/Header";
import { OrdemForm } from "@/components/OrdemForm";
import { prisma } from "@/lib/prisma";

export default async function NovaOrdemPage() {
  const [clientes, tecnicos] = await Promise.all([
    prisma.cliente.findMany({
      where: { ativo: true },
      orderBy: { nomeRazaoSocial: "asc" },
      select: { id: true, nomeRazaoSocial: true },
    }),
    prisma.usuario.findMany({
      where: { ativo: true },
      orderBy: { nome: "asc" },
      select: { id: true, nome: true },
    }),
  ]);

  return (
    <>
      <Header title="Nova ordem de manutenção" />
      <div className="p-8">
        <OrdemForm clientes={clientes} tecnicos={tecnicos} />
      </div>
    </>
  );
}
