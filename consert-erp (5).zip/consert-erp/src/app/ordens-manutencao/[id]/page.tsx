import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { OrdemItemForm } from "@/components/OrdemItemForm";
import { OrdemStatusForm } from "@/components/OrdemStatusForm";
import { GerarNotaButton } from "@/components/GerarNotaButton";
import { prisma } from "@/lib/prisma";

function formatarMoeda(valor: unknown) {
  return Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export default async function DetalheOrdemPage({
  params,
}: {
  params: { id: string };
}) {
  const ordemId = Number(params.id);

  const [ordem, produtos] = await Promise.all([
    prisma.ordemManutencao.findUnique({
      where: { id: ordemId },
      include: {
        cliente: true,
        tecnico: true,
        itens: { include: { produto: true } },
      },
    }),
    prisma.produto.findMany({
      where: { ativo: true, estoqueAtual: { gt: 0 } },
      orderBy: { nome: "asc" },
    }),
  ]);

  if (!ordem) {
    notFound();
  }

  const produtosSerializados = produtos.map((p) => ({
    id: p.id,
    codigo: p.codigo,
    nome: p.nome,
    unidade: p.unidade,
    estoqueAtual: p.estoqueAtual.toString(),
  }));

  const valorPecas = ordem.itens.reduce(
    (soma, item) => soma + Number(item.quantidade) * Number(item.valorUnitario),
    0
  );
  const valorTotal = valorPecas + Number(ordem.valorServico);

  return (
    <>
      <Header title={`Ordem ${ordem.numero}`} />
      <div className="grid grid-cols-3 gap-6 p-8">
        <div className="col-span-2 space-y-6">
          <div className="rounded-lg border border-neutral-200 bg-white p-5">
            <h2 className="mb-3 text-sm font-medium text-neutral-500">Dados da ordem</h2>
            <dl className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <dt className="text-neutral-500">Cliente</dt>
                <dd className="text-neutral-900">{ordem.cliente.nomeRazaoSocial}</dd>
              </div>
              <div>
                <dt className="text-neutral-500">Equipamento</dt>
                <dd className="text-neutral-900">{ordem.equipamento}</dd>
              </div>
              <div>
                <dt className="text-neutral-500">Número de série</dt>
                <dd className="text-neutral-900">{ordem.numeroSerie ?? "—"}</dd>
              </div>
              <div>
                <dt className="text-neutral-500">Técnico</dt>
                <dd className="text-neutral-900">{ordem.tecnico?.nome ?? "—"}</dd>
              </div>
              <div className="col-span-2">
                <dt className="text-neutral-500">Descrição do problema</dt>
                <dd className="text-neutral-900">{ordem.descricaoProblema}</dd>
              </div>
            </dl>
          </div>

          <div className="rounded-lg border border-neutral-200 bg-white p-5">
            <h2 className="mb-3 text-sm font-medium text-neutral-500">
              Peças usadas nesta ordem
            </h2>
            <div className="mb-4 overflow-hidden rounded-md border border-neutral-100">
              <table className="w-full text-left text-sm">
                <thead className="bg-neutral-50 text-neutral-500">
                  <tr>
                    <th className="px-3 py-2 font-medium">Produto</th>
                    <th className="px-3 py-2 font-medium">Quantidade</th>
                    <th className="px-3 py-2 font-medium">Valor unit.</th>
                    <th className="px-3 py-2 font-medium">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {ordem.itens.map((item) => (
                    <tr key={item.id} className="border-t border-neutral-100">
                      <td className="px-3 py-2 text-neutral-800">
                        {item.produto.codigo} — {item.produto.nome}
                      </td>
                      <td className="px-3 py-2 text-neutral-600">
                        {Number(item.quantidade)} {item.produto.unidade}
                      </td>
                      <td className="px-3 py-2 text-neutral-600">
                        {formatarMoeda(item.valorUnitario)}
                      </td>
                      <td className="px-3 py-2 text-neutral-600">
                        {formatarMoeda(Number(item.quantidade) * Number(item.valorUnitario))}
                      </td>
                    </tr>
                  ))}
                  {ordem.itens.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-3 py-4 text-center text-neutral-400">
                        Nenhuma peça usada ainda.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <OrdemItemForm ordemId={ordem.id} produtos={produtosSerializados} />
          </div>
        </div>

        <div className="space-y-6">
          <OrdemStatusForm
            ordemId={ordem.id}
            statusAtual={ordem.status}
            diagnosticoAtual={ordem.diagnostico ?? ""}
            valorServicoAtual={ordem.valorServico.toString()}
          />

          <div className="rounded-lg border border-neutral-200 bg-white p-5 text-sm">
            <h2 className="mb-3 font-medium text-neutral-500">Resumo financeiro</h2>
            <div className="flex justify-between py-1">
              <span className="text-neutral-500">Peças</span>
              <span className="text-neutral-800">{formatarMoeda(valorPecas)}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-neutral-500">Serviço</span>
              <span className="text-neutral-800">{formatarMoeda(ordem.valorServico)}</span>
            </div>
            <div className="mt-2 flex justify-between border-t border-neutral-100 pt-2 font-medium">
              <span className="text-neutral-700">Total</span>
              <span className="text-neutral-900">{formatarMoeda(valorTotal)}</span>
            </div>
          </div>

          {ordem.status === "concluida" && <GerarNotaButton ordemId={ordem.id} />}
        </div>
      </div>
    </>
  );
}
