import Link from "next/link";
import { Header } from "@/components/Header";
import { prisma } from "@/lib/prisma";

const rotulosStatus: Record<string, { texto: string; classe: string }> = {
  aberta: { texto: "Aberta", classe: "bg-blue-100 text-blue-700" },
  em_andamento: { texto: "Em andamento", classe: "bg-amber-100 text-amber-700" },
  aguardando_peca: { texto: "Aguardando peça", classe: "bg-orange-100 text-orange-700" },
  concluida: { texto: "Concluída", classe: "bg-green-100 text-green-700" },
  cancelada: { texto: "Cancelada", classe: "bg-neutral-200 text-neutral-600" },
};

export default async function OrdensManutencaoPage() {
  const ordens = await prisma.ordemManutencao.findMany({
    include: { cliente: true, tecnico: true },
    orderBy: { dataAbertura: "desc" },
  });

  return (
    <>
      <Header title="Ordens de manutenção" />
      <div className="p-8">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-neutral-500">{ordens.length} ordem(ns) registrada(s)</p>
          <Link
            href="/ordens-manutencao/novo"
            className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800"
          >
            Nova ordem de manutenção
          </Link>
        </div>

        <div className="overflow-hidden rounded-lg border border-neutral-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-neutral-50 text-neutral-500">
              <tr>
                <th className="px-4 py-3 font-medium">Número</th>
                <th className="px-4 py-3 font-medium">Cliente</th>
                <th className="px-4 py-3 font-medium">Equipamento</th>
                <th className="px-4 py-3 font-medium">Técnico</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Abertura</th>
              </tr>
            </thead>
            <tbody>
              {ordens.map((ordem) => {
                const status = rotulosStatus[ordem.status];
                return (
                  <tr key={ordem.id} className="border-t border-neutral-100">
                    <td className="px-4 py-3">
                      <Link
                        href={`/ordens-manutencao/${ordem.id}`}
                        className="font-mono text-neutral-900 hover:underline"
                      >
                        {ordem.numero}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-neutral-700">
                      {ordem.cliente.nomeRazaoSocial}
                    </td>
                    <td className="px-4 py-3 text-neutral-700">{ordem.equipamento}</td>
                    <td className="px-4 py-3 text-neutral-600">
                      {ordem.tecnico?.nome ?? "—"}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${status.classe}`}>
                        {status.texto}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-neutral-600">
                      {ordem.dataAbertura.toLocaleDateString("pt-BR")}
                    </td>
                  </tr>
                );
              })}
              {ordens.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-neutral-400">
                    Nenhuma ordem de manutenção registrada ainda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
