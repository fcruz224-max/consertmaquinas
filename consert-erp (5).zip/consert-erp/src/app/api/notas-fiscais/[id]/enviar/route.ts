import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// Este endpoint é o único lugar que vai falar com o provedor de NF-e (Focus NFe, PlugNotas etc.)
// quando ele for contratado. Por enquanto, sem as variáveis de ambiente configuradas,
// ele apenas explica o que falta — não inventa uma emissão fiscal falsa.
export async function POST(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  const notaId = Number(params.id);

  const nota = await prisma.notaFiscal.findUnique({ where: { id: notaId } });
  if (!nota) {
    return NextResponse.json({ erro: "Nota fiscal não encontrada." }, { status: 404 });
  }
  if (nota.status !== "rascunho") {
    return NextResponse.json({ erro: "Esta nota já foi enviada anteriormente." }, { status: 400 });
  }

  const providerUrl = process.env.NFE_PROVIDER_API_URL;
  const providerToken = process.env.NFE_PROVIDER_API_TOKEN;

  if (!providerUrl || !providerToken) {
    return NextResponse.json(
      {
        erro:
          "Nenhum provedor de NF-e configurado ainda. Configure NFE_PROVIDER_API_URL e " +
          "NFE_PROVIDER_API_TOKEN nas variáveis de ambiente depois de contratar um provedor " +
          "(ex: Focus NFe) e ter o certificado digital cadastrado nele.",
      },
      { status: 400 }
    );
  }

  // Exemplo de como a chamada real ficaria (ajustar conforme a documentação do provedor escolhido):
  //
  // const resposta = await fetch(`${providerUrl}/nfse`, {
  //   method: "POST",
  //   headers: { Authorization: `Bearer ${providerToken}`, "Content-Type": "application/json" },
  //   body: JSON.stringify({ ...dados da nota... }),
  // });
  // const resultado = await resposta.json();
  //
  // await prisma.notaFiscal.update({
  //   where: { id: notaId },
  //   data: {
  //     status: "enviada",
  //     provedorIdExterno: resultado.id,
  //   },
  // });

  return NextResponse.json(
    { erro: "Integração com o provedor ainda não implementada nesta versão." },
    { status: 501 }
  );
}
