import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const notas = await prisma.notaFiscal.findMany({
    include: { cliente: true },
    orderBy: { criadoEm: "desc" },
  });

  return NextResponse.json(notas);
}

// Gera uma nota fiscal em RASCUNHO a partir de uma ordem de manutenção concluída,
// somando as peças usadas + o valor do serviço. Ainda não envia nada à SEFAZ —
// isso só acontece em /api/notas-fiscais/[id]/enviar, quando houver provedor configurado.
export async function POST(request: NextRequest) {
  const dados = await request.json();
  const ordemManutencaoId = Number(dados.ordemManutencaoId);

  if (!ordemManutencaoId) {
    return NextResponse.json(
      { erro: "Informe a ordem de manutenção de origem." },
      { status: 400 }
    );
  }

  const ordem = await prisma.ordemManutencao.findUnique({
    where: { id: ordemManutencaoId },
    include: { itens: { include: { produto: true } } },
  });

  if (!ordem) {
    return NextResponse.json({ erro: "Ordem de manutenção não encontrada." }, { status: 404 });
  }
  if (ordem.status !== "concluida") {
    return NextResponse.json(
      { erro: "Só é possível emitir nota fiscal para ordens concluídas." },
      { status: 400 }
    );
  }

  const jaExiste = await prisma.notaFiscal.findFirst({
    where: { ordemManutencaoId, status: { not: "cancelada" } },
  });
  if (jaExiste) {
    return NextResponse.json(
      { erro: "Já existe uma nota fiscal para esta ordem de manutenção." },
      { status: 409 }
    );
  }

  const itensPecas = ordem.itens.map((item) => ({
    produtoId: item.produtoId,
    descricao: item.produto.nome,
    ncm: item.produto.ncm,
    cfop: item.produto.cfopPadrao,
    quantidade: item.quantidade,
    valorUnitario: item.valorUnitario,
    valorTotal: Number(item.quantidade) * Number(item.valorUnitario),
  }));

  const itemServico =
    Number(ordem.valorServico) > 0
      ? [
          {
            produtoId: null,
            descricao: `Serviço de manutenção — ${ordem.equipamento} (${ordem.numero})`,
            ncm: null,
            cfop: null,
            quantidade: 1,
            valorUnitario: ordem.valorServico,
            valorTotal: Number(ordem.valorServico),
          },
        ]
      : [];

  const todosItens = [...itensPecas, ...itemServico];
  const valorTotal = todosItens.reduce((soma, item) => soma + item.valorTotal, 0);

  const nota = await prisma.notaFiscal.create({
    data: {
      tipo: "nfse",
      clienteId: ordem.clienteId,
      ordemManutencaoId: ordem.id,
      status: "rascunho",
      valorTotal,
      itens: { create: todosItens },
    },
    include: { itens: true },
  });

  return NextResponse.json(nota, { status: 201 });
}
