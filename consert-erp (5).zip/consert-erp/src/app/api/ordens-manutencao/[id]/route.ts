import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  const ordem = await prisma.ordemManutencao.findUnique({
    where: { id: Number(params.id) },
    include: {
      cliente: true,
      tecnico: true,
      itens: { include: { produto: true } },
    },
  });

  if (!ordem) {
    return NextResponse.json({ erro: "Ordem não encontrada." }, { status: 404 });
  }

  return NextResponse.json(ordem);
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const dados = await request.json();

  const dataConclusao =
    dados.status === "concluida" || dados.status === "cancelada"
      ? new Date()
      : null;

  const ordem = await prisma.ordemManutencao.update({
    where: { id: Number(params.id) },
    data: {
      status: dados.status,
      diagnostico: dados.diagnostico || null,
      valorServico: dados.valorServico !== undefined ? Number(dados.valorServico) : undefined,
      tecnicoId: dados.tecnicoId ? Number(dados.tecnicoId) : null,
      observacoes: dados.observacoes || null,
      ...(dataConclusao ? { dataConclusao } : {}),
    },
  });

  return NextResponse.json(ordem);
}
