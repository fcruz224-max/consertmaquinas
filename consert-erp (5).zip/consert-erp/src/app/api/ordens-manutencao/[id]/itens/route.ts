import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const ordemManutencaoId = Number(params.id);
  const dados = await request.json();
  const session = await getServerSession(authOptions);

  const produtoId = Number(dados.produtoId);
  const quantidade = Number(dados.quantidade);

  if (!produtoId || !quantidade || quantidade <= 0) {
    return NextResponse.json(
      { erro: "Produto e quantidade (maior que zero) são obrigatórios." },
      { status: 400 }
    );
  }

  const produto = await prisma.produto.findUnique({ where: { id: produtoId } });
  if (!produto) {
    return NextResponse.json({ erro: "Produto não encontrado." }, { status: 404 });
  }
  if (Number(produto.estoqueAtual) < quantidade) {
    return NextResponse.json(
      { erro: `Estoque insuficiente. Disponível: ${produto.estoqueAtual} ${produto.unidade}.` },
      { status: 400 }
    );
  }

  const usuario = session?.user?.email
    ? await prisma.usuario.findUnique({ where: { email: session.user.email } })
    : null;

  const valorUnitario = Number(produto.precoVenda);

  // Registra o item da OS, dá baixa no estoque e grava a movimentação — tudo junto,
  // para o estoque nunca ficar dessincronizado da ordem de manutenção.
  const [item] = await prisma.$transaction([
    prisma.ordemManutencaoItem.create({
      data: { ordemManutencaoId, produtoId, quantidade, valorUnitario },
    }),
    prisma.produto.update({
      where: { id: produtoId },
      data: { estoqueAtual: { decrement: quantidade } },
    }),
    prisma.movimentacaoEstoque.create({
      data: {
        produtoId,
        tipo: "saida",
        quantidade,
        motivo: "uso_os",
        ordemManutencaoId,
        usuarioId: usuario?.id ?? null,
        observacoes: `Usado na ordem de manutenção #${ordemManutencaoId}`,
      },
    }),
  ]);

  return NextResponse.json(item, { status: 201 });
}
