import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const ordens = await prisma.ordemManutencao.findMany({
    include: { cliente: true, tecnico: true },
    orderBy: { dataAbertura: "desc" },
  });

  return NextResponse.json(ordens);
}

export async function POST(request: NextRequest) {
  const dados = await request.json();

  if (!dados.clienteId || !dados.equipamento || !dados.descricaoProblema) {
    return NextResponse.json(
      { erro: "Cliente, equipamento e descrição do problema são obrigatórios." },
      { status: 400 }
    );
  }

  // Cria a OS com um número temporário, e depois grava o número definitivo
  // baseado no id gerado (ex: OS-00001), garantindo sequência sem corrida entre requisições simultâneas.
  const criada = await prisma.ordemManutencao.create({
    data: {
      numero: "temp",
      clienteId: Number(dados.clienteId),
      equipamento: dados.equipamento,
      numeroSerie: dados.numeroSerie || null,
      descricaoProblema: dados.descricaoProblema,
      tecnicoId: dados.tecnicoId ? Number(dados.tecnicoId) : null,
    },
  });

  const ordem = await prisma.ordemManutencao.update({
    where: { id: criada.id },
    data: { numero: `OS-${String(criada.id).padStart(5, "0")}` },
  });

  return NextResponse.json(ordem, { status: 201 });
}
