import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const movimentacoes = await prisma.movimentacaoEstoque.findMany({
    include: { produto: true, usuario: true },
    orderBy: { criadoEm: "desc" },
    take: 200,
  });

  return NextResponse.json(movimentacoes);
}

export async function POST(request: NextRequest) {
  const dados = await request.json();
  const session = await getServerSession(authOptions);

  const produtoId = Number(dados.produtoId);
  const quantidade = Number(dados.quantidade);
  const tipo = dados.tipo;

  if (!produtoId || !quantidade || quantidade <= 0 || !["entrada", "saida"].includes(tipo)) {
    return NextResponse.json(
      { erro: "Produto, tipo (entrada/saida) e quantidade (maior que zero) são obrigatórios." },
      { status: 400 }
    );
  }

  const produto = await prisma.produto.findUnique({ where: { id: produtoId } });
  if (!produto) {
    return NextResponse.json({ erro: "Produto não encontrado." }, { status: 404 });
  }

  if (tipo === "saida" && Number(produto.estoqueAtual) < quantidade) {
    return NextResponse.json(
      {
        erro: `Estoque insuficiente. Disponível: ${produto.estoqueAtual} ${produto.unidade}.`,
      },
      { status: 400 }
    );
  }

  const usuario = session?.user?.email
    ? await prisma.usuario.findUnique({ where: { email: session.user.email } })
    : null;

  // Transação: cria a movimentação e atualiza o saldo do produto juntos,
  // para nunca ficar um registrado sem o outro.
  const [movimentacao] = await prisma.$transaction([
    prisma.movimentacaoEstoque.create({
      data: {
        produtoId,
        tipo,
        quantidade,
        motivo: dados.motivo || (tipo === "entrada" ? "compra" : "ajuste"),
        observacoes: dados.observacoes || null,
        usuarioId: usuario?.id ?? null,
      },
    }),
    prisma.produto.update({
      where: { id: produtoId },
      data: {
        estoqueAtual: {
          [tipo === "entrada" ? "increment" : "decrement"]: quantidade,
        },
      },
    }),
  ]);

  return NextResponse.json(movimentacao, { status: 201 });
}
