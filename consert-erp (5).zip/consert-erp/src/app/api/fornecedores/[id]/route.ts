import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  const fornecedor = await prisma.fornecedor.findUnique({
    where: { id: Number(params.id) },
  });

  if (!fornecedor) {
    return NextResponse.json({ erro: "Fornecedor não encontrado." }, { status: 404 });
  }

  return NextResponse.json(fornecedor);
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const dados = await request.json();

  const fornecedor = await prisma.fornecedor.update({
    where: { id: Number(params.id) },
    data: {
      nomeRazaoSocial: dados.nomeRazaoSocial,
      cnpj: dados.cnpj || null,
      telefone: dados.telefone || null,
      email: dados.email || null,
    },
  });

  return NextResponse.json(fornecedor);
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  await prisma.fornecedor.update({
    where: { id: Number(params.id) },
    data: { ativo: false },
  });

  return NextResponse.json({ ok: true });
}
