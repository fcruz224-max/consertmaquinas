import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const fornecedores = await prisma.fornecedor.findMany({
    where: { ativo: true },
    orderBy: { nomeRazaoSocial: "asc" },
  });

  return NextResponse.json(fornecedores);
}

export async function POST(request: NextRequest) {
  const dados = await request.json();

  if (!dados.nomeRazaoSocial) {
    return NextResponse.json(
      { erro: "Nome/razão social é obrigatório." },
      { status: 400 }
    );
  }

  const fornecedor = await prisma.fornecedor.create({
    data: {
      nomeRazaoSocial: dados.nomeRazaoSocial,
      cnpj: dados.cnpj || null,
      telefone: dados.telefone || null,
      email: dados.email || null,
    },
  });

  return NextResponse.json(fornecedor, { status: 201 });
}
