import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  const produto = await prisma.produto.findUnique({
    where: { id: Number(params.id) },
  });

  if (!produto) {
    return NextResponse.json({ erro: "Produto não encontrado." }, { status: 404 });
  }

  return NextResponse.json(produto);
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const dados = await request.json();

  const produto = await prisma.produto.update({
    where: { id: Number(params.id) },
    data: {
      codigo: dados.codigo,
      nome: dados.nome,
      descricao: dados.descricao || null,
      unidade: dados.unidade || "UN",
      ncm: dados.ncm || null,
      cfopPadrao: dados.cfopPadrao || null,
      precoCusto: Number(dados.precoCusto) || 0,
      precoVenda: Number(dados.precoVenda) || 0,
      estoqueAtual: Number(dados.estoqueAtual) || 0,
      estoqueMinimo: Number(dados.estoqueMinimo) || 0,
      fornecedorId: dados.fornecedorId ? Number(dados.fornecedorId) : null,
    },
  });

  return NextResponse.json(produto);
}

// Exclusão lógica: mantém o histórico de movimentações e notas fiscais já emitidas
export async function DELETE(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  await prisma.produto.update({
    where: { id: Number(params.id) },
    data: { ativo: false },
  });

  return NextResponse.json({ ok: true });
}
