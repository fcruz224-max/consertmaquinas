import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest) {
  const busca = request.nextUrl.searchParams.get("busca") ?? "";

  const produtos = await prisma.produto.findMany({
    where: {
      ativo: true,
      OR: busca
        ? [
            { nome: { contains: busca, mode: "insensitive" } },
            { codigo: { contains: busca, mode: "insensitive" } },
          ]
        : undefined,
    },
    orderBy: { nome: "asc" },
  });

  return NextResponse.json(produtos);
}

export async function POST(request: NextRequest) {
  const dados = await request.json();

  if (!dados.codigo || !dados.nome) {
    return NextResponse.json(
      { erro: "Código e nome são obrigatórios." },
      { status: 400 }
    );
  }

  const produtoExistente = await prisma.produto.findUnique({
    where: { codigo: dados.codigo },
  });
  if (produtoExistente) {
    return NextResponse.json(
      { erro: "Já existe um produto cadastrado com esse código." },
      { status: 409 }
    );
  }

  const produto = await prisma.produto.create({
    data: {
      codigo: dados.codigo,
      nome: dados.nome,
      descricao: dados.descricao || null,
      unidade: dados.unidade || "UN",
      ncm: dados.ncm || null,
      cfopPadrao: dados.cfopPadrao || null,
      precoCusto: Number(dados.precoCusto) || 0,
      precoVenda: Number(dados.precoVenda) || 0,
      estoqueAtual: Number(dados.estoqueAtual) || 0,
      estoqueMinimo: Number(dados.estoqueMinimo) || 0,
      fornecedorId: dados.fornecedorId ? Number(dados.fornecedorId) : null,
    },
  });

  return NextResponse.json(produto, { status: 201 });
}
