import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  const cliente = await prisma.cliente.findUnique({
    where: { id: Number(params.id) },
  });

  if (!cliente) {
    return NextResponse.json({ erro: "Cliente não encontrado." }, { status: 404 });
  }

  return NextResponse.json(cliente);
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const dados = await request.json();

  const cliente = await prisma.cliente.update({
    where: { id: Number(params.id) },
    data: {
      tipoPessoa: dados.tipoPessoa,
      nomeRazaoSocial: dados.nomeRazaoSocial,
      cpfCnpj: dados.cpfCnpj,
      inscricaoEstadual: dados.inscricaoEstadual || null,
      email: dados.email || null,
      telefone: dados.telefone || null,
      endereco: dados.endereco || null,
      numero: dados.numero || null,
      complemento: dados.complemento || null,
      bairro: dados.bairro || null,
      cidade: dados.cidade || null,
      uf: dados.uf || null,
      cep: dados.cep || null,
      observacoes: dados.observacoes || null,
    },
  });

  return NextResponse.json(cliente);
}

// Exclusão lógica: mantém o histórico (OS e notas fiscais já emitidas continuam íntegras)
export async function DELETE(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  await prisma.cliente.update({
    where: { id: Number(params.id) },
    data: { ativo: false },
  });

  return NextResponse.json({ ok: true });
}
