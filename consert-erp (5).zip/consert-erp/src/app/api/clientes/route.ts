import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest) {
  const busca = request.nextUrl.searchParams.get("busca") ?? "";

  const clientes = await prisma.cliente.findMany({
    where: {
      ativo: true,
      OR: busca
        ? [
            { nomeRazaoSocial: { contains: busca, mode: "insensitive" } },
            { cpfCnpj: { contains: busca } },
          ]
        : undefined,
    },
    orderBy: { nomeRazaoSocial: "asc" },
  });

  return NextResponse.json(clientes);
}

export async function POST(request: NextRequest) {
  const dados = await request.json();

  if (!dados.nomeRazaoSocial || !dados.cpfCnpj || !dados.tipoPessoa) {
    return NextResponse.json(
      { erro: "Nome/razão social, CPF/CNPJ e tipo de pessoa são obrigatórios." },
      { status: 400 }
    );
  }

  const clienteExistente = await prisma.cliente.findUnique({
    where: { cpfCnpj: dados.cpfCnpj },
  });
  if (clienteExistente) {
    return NextResponse.json(
      { erro: "Já existe um cliente cadastrado com esse CPF/CNPJ." },
      { status: 409 }
    );
  }

  const cliente = await prisma.cliente.create({
    data: {
      tipoPessoa: dados.tipoPessoa,
      nomeRazaoSocial: dados.nomeRazaoSocial,
      cpfCnpj: dados.cpfCnpj,
      inscricaoEstadual: dados.inscricaoEstadual || null,
      email: dados.email || null,
      telefone: dados.telefone || null,
      endereco: dados.endereco || null,
      numero: dados.numero || null,
      complemento: dados.complemento || null,
      bairro: dados.bairro || null,
      cidade: dados.cidade || null,
      uf: dados.uf || null,
      cep: dados.cep || null,
      observacoes: dados.observacoes || null,
    },
  });

  return NextResponse.json(cliente, { status: 201 });
}
