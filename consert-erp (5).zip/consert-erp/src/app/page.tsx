import { Header } from "@/components/Header";
import { prisma } from "@/lib/prisma";

export default async function DashboardPage() {
  const [totalClientes, totalProdutos, osAbertas, estoqueBaixoResultado] =
    await Promise.all([
      prisma.cliente.count({ where: { ativo: true } }),
      prisma.produto.count({ where: { ativo: true } }),
      prisma.ordemManutencao.count({
        where: { status: { in: ["aberta", "em_andamento", "aguardando_peca"] } },
      }),
      // Comparar duas colunas da mesma tabela exige SQL bruto no Prisma
      prisma.$queryRaw<{ total: bigint }[]>`
        SELECT COUNT(*)::bigint AS total FROM produtos
        WHERE ativo = true AND estoque_atual <= estoque_minimo
      `,
    ]);

  const estoqueBaixo = Number(estoqueBaixoResultado[0]?.total ?? 0);

  const cards = [
    { label: "Clientes ativos", value: totalClientes },
    { label: "Produtos cadastrados", value: totalProdutos },
    { label: "Ordens de manutenção em aberto", value: osAbertas },
    { label: "Itens com estoque baixo", value: estoqueBaixo },
  ];

  return (
    <>
      <Header title="Painel" />
      <div className="grid grid-cols-2 gap-4 p-8 md:grid-cols-4">
        {cards.map((card) => (
          <div
            key={card.label}
            className="rounded-lg border border-neutral-200 bg-white p-5"
          >
            <p className="text-2xl font-medium text-neutral-900">{card.value}</p>
            <p className="mt-1 text-sm text-neutral-500">{card.label}</p>
          </div>
        ))}
      </div>
    </>
  );
}
