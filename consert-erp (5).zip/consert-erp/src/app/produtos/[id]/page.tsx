import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { ProdutoForm } from "@/components/ProdutoForm";
import { prisma } from "@/lib/prisma";

export default async function EditarProdutoPage({
  params,
}: {
  params: { id: string };
}) {
  const produto = await prisma.produto.findUnique({
    where: { id: Number(params.id) },
  });

  if (!produto) {
    notFound();
  }

  const fornecedores = await prisma.fornecedor.findMany({
    where: { ativo: true },
    orderBy: { nomeRazaoSocial: "asc" },
    select: { id: true, nomeRazaoSocial: true },
  });

  // Campos Decimal do Prisma precisam virar string/number simples
  // antes de serem passados para um client component.
  const produtoSerializado = {
    ...produto,
    precoCusto: produto.precoCusto.toString(),
    precoVenda: produto.precoVenda.toString(),
    estoqueAtual: produto.estoqueAtual.toString(),
    estoqueMinimo: produto.estoqueMinimo.toString(),
  };

  return (
    <>
      <Header title={`Editar produto — ${produto.nome}`} />
      <div className="p-8">
        <ProdutoForm produto={produtoSerializado} fornecedores={fornecedores} />
      </div>
    </>
  );
}
