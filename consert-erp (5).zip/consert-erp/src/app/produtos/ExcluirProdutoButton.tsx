"use client";

import { useRouter } from "next/navigation";

export function ExcluirProdutoButton({ id }: { id: number }) {
  const router = useRouter();

  async function excluir() {
    const confirmado = confirm("Tem certeza que deseja remover este produto?");
    if (!confirmado) return;

    await fetch(`/api/produtos/${id}`, { method: "DELETE" });
    router.refresh();
  }

  return (
    <button
      onClick={excluir}
      className="text-sm text-red-600 hover:text-red-800"
    >
      Remover
    </button>
  );
}
