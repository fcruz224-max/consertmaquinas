import { Header } from "@/components/Header";
import { ProdutoForm } from "@/components/ProdutoForm";
import { prisma } from "@/lib/prisma";

export default async function NovoProdutoPage() {
  const fornecedores = await prisma.fornecedor.findMany({
    where: { ativo: true },
    orderBy: { nomeRazaoSocial: "asc" },
    select: { id: true, nomeRazaoSocial: true },
  });

  return (
    <>
      <Header title="Novo produto" />
      <div className="p-8">
        <ProdutoForm fornecedores={fornecedores} />
      </div>
    </>
  );
}
