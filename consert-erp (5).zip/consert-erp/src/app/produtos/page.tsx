import Link from "next/link";
import { Header } from "@/components/Header";
import { prisma } from "@/lib/prisma";
import { ExcluirProdutoButton } from "./ExcluirProdutoButton";

function formatarMoeda(valor: unknown) {
  return Number(valor).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

export default async function ProdutosPage() {
  const produtos = await prisma.produto.findMany({
    where: { ativo: true },
    orderBy: { nome: "asc" },
  });

  const comEstoqueBaixo = produtos.filter(
    (p) => Number(p.estoqueAtual) <= Number(p.estoqueMinimo)
  ).length;

  return (
    <>
      <Header title="Estoque" />
      <div className="p-8">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-neutral-500">
            {produtos.length} produto(s) cadastrado(s)
            {comEstoqueBaixo > 0 && (
              <span className="ml-2 rounded-full bg-amber-500/10 px-2 py-0.5 text-xs font-medium text-amber-600">
                {comEstoqueBaixo} com estoque baixo
              </span>
            )}
          </p>
          <Link
            href="/produtos/novo"
            className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800"
          >
            Novo produto
          </Link>
        </div>

        <div className="overflow-hidden rounded-lg border border-neutral-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-neutral-50 text-neutral-500">
              <tr>
                <th className="px-4 py-3 font-medium">Código</th>
                <th className="px-4 py-3 font-medium">Nome</th>
                <th className="px-4 py-3 font-medium">Estoque</th>
                <th className="px-4 py-3 font-medium">Preço de venda</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {produtos.map((produto) => {
                const estoqueBaixo =
                  Number(produto.estoqueAtual) <= Number(produto.estoqueMinimo);
                return (
                  <tr key={produto.id} className="border-t border-neutral-100">
                    <td className="px-4 py-3 font-mono text-neutral-600">
                      {produto.codigo}
                    </td>
                    <td className="px-4 py-3 text-neutral-900">{produto.nome}</td>
                    <td className="px-4 py-3">
                      <span
                        className={
                          estoqueBaixo
                            ? "rounded-full bg-amber-500/10 px-2 py-0.5 text-xs font-medium text-amber-600"
                            : "text-neutral-600"
                        }
                      >
                        {Number(produto.estoqueAtual)} {produto.unidade}
                        {estoqueBaixo ? " — abaixo do mínimo" : ""}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-neutral-600">
                      {formatarMoeda(produto.precoVenda)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex justify-end gap-3">
                        <Link
                          href={`/produtos/${produto.id}`}
                          className="text-sm text-neutral-600 hover:text-graphite-950"
                        >
                          Editar
                        </Link>
                        <ExcluirProdutoButton id={produto.id} />
                      </div>
                    </td>
                  </tr>
                );
              })}
              {produtos.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-neutral-400">
                    Nenhum produto cadastrado ainda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
