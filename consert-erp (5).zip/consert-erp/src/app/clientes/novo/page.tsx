import { Header } from "@/components/Header";
import { ClienteForm } from "@/components/ClienteForm";

export default function NovoClientePage() {
  return (
    <>
      <Header title="Novo cliente" />
      <div className="p-8">
        <ClienteForm />
      </div>
    </>
  );
}
