import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { ClienteForm } from "@/components/ClienteForm";
import { prisma } from "@/lib/prisma";

export default async function EditarClientePage({
  params,
}: {
  params: { id: string };
}) {
  const cliente = await prisma.cliente.findUnique({
    where: { id: Number(params.id) },
  });

  if (!cliente) {
    notFound();
  }

  return (
    <>
      <Header title={`Editar cliente — ${cliente.nomeRazaoSocial}`} />
      <div className="p-8">
        <ClienteForm cliente={cliente} />
      </div>
    </>
  );
}
