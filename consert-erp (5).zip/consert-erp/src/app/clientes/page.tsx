import Link from "next/link";
import { Header } from "@/components/Header";
import { prisma } from "@/lib/prisma";
import { ExcluirClienteButton } from "./ExcluirClienteButton";

export default async function ClientesPage() {
  const clientes = await prisma.cliente.findMany({
    where: { ativo: true },
    orderBy: { nomeRazaoSocial: "asc" },
  });

  return (
    <>
      <Header title="Clientes" />
      <div className="p-8">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-neutral-500">
            {clientes.length} cliente(s) cadastrado(s)
          </p>
          <Link
            href="/clientes/novo"
            className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800"
          >
            Novo cliente
          </Link>
        </div>

        <div className="overflow-hidden rounded-lg border border-neutral-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-neutral-50 text-neutral-500">
              <tr>
                <th className="px-4 py-3 font-medium">Nome / razão social</th>
                <th className="px-4 py-3 font-medium">CPF / CNPJ</th>
                <th className="px-4 py-3 font-medium">Telefone</th>
                <th className="px-4 py-3 font-medium">Cidade</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {clientes.map((cliente) => (
                <tr key={cliente.id} className="border-t border-neutral-100">
                  <td className="px-4 py-3 text-neutral-900">
                    {cliente.nomeRazaoSocial}
                  </td>
                  <td className="px-4 py-3 font-mono text-neutral-600">
                    {cliente.cpfCnpj}
                  </td>
                  <td className="px-4 py-3 text-neutral-600">
                    {cliente.telefone ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-neutral-600">
                    {cliente.cidade ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-3">
                      <Link
                        href={`/clientes/${cliente.id}`}
                        className="text-sm text-neutral-600 hover:text-graphite-950"
                      >
                        Editar
                      </Link>
                      <ExcluirClienteButton id={cliente.id} />
                    </div>
                  </td>
                </tr>
              ))}
              {clientes.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-neutral-400">
                    Nenhum cliente cadastrado ainda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
