"use client";

import { signIn } from "next-auth/react";

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-graphite-950">
      <div className="w-full max-w-sm rounded-lg border border-graphite-800 bg-graphite-900 p-8 text-center">
        <p className="text-sm text-neutral-400">Consert Máquinas</p>
        <h1 className="mt-1 text-xl font-medium text-neutral-100">
          Acessar o sistema
        </h1>
        <p className="mt-2 text-sm text-neutral-400">
          Entre com a sua conta Google da empresa.
        </p>
        <button
          onClick={() => signIn("google", { callbackUrl: "/" })}
          className="mt-6 w-full rounded-md bg-amber-500 px-4 py-2.5 text-sm font-medium text-graphite-950 transition hover:bg-amber-600"
        >
          Entrar com o Google
        </button>
      </div>
    </div>
  );
}
