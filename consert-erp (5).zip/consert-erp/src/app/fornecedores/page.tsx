import Link from "next/link";
import { Header } from "@/components/Header";
import { prisma } from "@/lib/prisma";
import { ExcluirFornecedorButton } from "./ExcluirFornecedorButton";

export default async function FornecedoresPage() {
  const fornecedores = await prisma.fornecedor.findMany({
    where: { ativo: true },
    orderBy: { nomeRazaoSocial: "asc" },
  });

  return (
    <>
      <Header title="Fornecedores" />
      <div className="p-8">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-neutral-500">
            {fornecedores.length} fornecedor(es) cadastrado(s)
          </p>
          <Link
            href="/fornecedores/novo"
            className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800"
          >
            Novo fornecedor
          </Link>
        </div>

        <div className="overflow-hidden rounded-lg border border-neutral-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-neutral-50 text-neutral-500">
              <tr>
                <th className="px-4 py-3 font-medium">Nome / razão social</th>
                <th className="px-4 py-3 font-medium">CNPJ</th>
                <th className="px-4 py-3 font-medium">Telefone</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {fornecedores.map((fornecedor) => (
                <tr key={fornecedor.id} className="border-t border-neutral-100">
                  <td className="px-4 py-3 text-neutral-900">
                    {fornecedor.nomeRazaoSocial}
                  </td>
                  <td className="px-4 py-3 font-mono text-neutral-600">
                    {fornecedor.cnpj ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-neutral-600">
                    {fornecedor.telefone ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-3">
                      <Link
                        href={`/fornecedores/${fornecedor.id}`}
                        className="text-sm text-neutral-600 hover:text-graphite-950"
                      >
                        Editar
                      </Link>
                      <ExcluirFornecedorButton id={fornecedor.id} />
                    </div>
                  </td>
                </tr>
              ))}
              {fornecedores.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-4 py-8 text-center text-neutral-400">
                    Nenhum fornecedor cadastrado ainda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
