"use client";

import { useRouter } from "next/navigation";

export function ExcluirFornecedorButton({ id }: { id: number }) {
  const router = useRouter();

  async function excluir() {
    const confirmado = confirm("Tem certeza que deseja remover este fornecedor?");
    if (!confirmado) return;

    await fetch(`/api/fornecedores/${id}`, { method: "DELETE" });
    router.refresh();
  }

  return (
    <button onClick={excluir} className="text-sm text-red-600 hover:text-red-800">
      Remover
    </button>
  );
}
