import { Header } from "@/components/Header";
import { FornecedorForm } from "@/components/FornecedorForm";

export default function NovoFornecedorPage() {
  return (
    <>
      <Header title="Novo fornecedor" />
      <div className="p-8">
        <FornecedorForm />
      </div>
    </>
  );
}
