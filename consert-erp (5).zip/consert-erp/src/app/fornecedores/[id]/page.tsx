import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { FornecedorForm } from "@/components/FornecedorForm";
import { prisma } from "@/lib/prisma";

export default async function EditarFornecedorPage({
  params,
}: {
  params: { id: string };
}) {
  const fornecedor = await prisma.fornecedor.findUnique({
    where: { id: Number(params.id) },
  });

  if (!fornecedor) {
    notFound();
  }

  return (
    <>
      <Header title={`Editar fornecedor — ${fornecedor.nomeRazaoSocial}`} />
      <div className="p-8">
        <FornecedorForm fornecedor={fornecedor} />
      </div>
    </>
  );
}
