import { Header } from "@/components/Header";
import { MovimentacaoForm } from "@/components/MovimentacaoForm";
import { prisma } from "@/lib/prisma";

export default async function NovaMovimentacaoPage() {
  const produtos = await prisma.produto.findMany({
    where: { ativo: true },
    orderBy: { nome: "asc" },
  });

  const produtosSerializados = produtos.map((p) => ({
    id: p.id,
    codigo: p.codigo,
    nome: p.nome,
    unidade: p.unidade,
    estoqueAtual: p.estoqueAtual.toString(),
  }));

  return (
    <>
      <Header title="Nova movimentação de estoque" />
      <div className="p-8">
        {produtos.length === 0 ? (
          <p className="text-sm text-neutral-500">
            Cadastre ao menos um produto antes de registrar movimentações.
          </p>
        ) : (
          <MovimentacaoForm produtos={produtosSerializados} />
        )}
      </div>
    </>
  );
}
