import Link from "next/link";
import { Header } from "@/components/Header";
import { prisma } from "@/lib/prisma";

const rotulosMotivo: Record<string, string> = {
  compra: "Compra de fornecedor",
  devolucao: "Devolução de cliente",
  ajuste: "Ajuste de inventário",
  uso_os: "Uso em ordem de manutenção",
  venda: "Venda avulsa",
};

export default async function MovimentacoesPage() {
  const movimentacoes = await prisma.movimentacaoEstoque.findMany({
    include: { produto: true, usuario: true },
    orderBy: { criadoEm: "desc" },
    take: 200,
  });

  return (
    <>
      <Header title="Entradas e saídas de estoque" />
      <div className="p-8">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-neutral-500">
            Últimas {movimentacoes.length} movimentações
          </p>
          <Link
            href="/movimentacoes/novo"
            className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800"
          >
            Nova movimentação
          </Link>
        </div>

        <div className="overflow-hidden rounded-lg border border-neutral-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-neutral-50 text-neutral-500">
              <tr>
                <th className="px-4 py-3 font-medium">Data</th>
                <th className="px-4 py-3 font-medium">Tipo</th>
                <th className="px-4 py-3 font-medium">Produto</th>
                <th className="px-4 py-3 font-medium">Quantidade</th>
                <th className="px-4 py-3 font-medium">Motivo</th>
                <th className="px-4 py-3 font-medium">Usuário</th>
              </tr>
            </thead>
            <tbody>
              {movimentacoes.map((mov) => (
                <tr key={mov.id} className="border-t border-neutral-100">
                  <td className="px-4 py-3 text-neutral-600">
                    {mov.criadoEm.toLocaleString("pt-BR")}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={
                        mov.tipo === "entrada"
                          ? "rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700"
                          : "rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700"
                      }
                    >
                      {mov.tipo === "entrada" ? "Entrada" : "Saída"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-neutral-900">
                    {mov.produto.codigo} — {mov.produto.nome}
                  </td>
                  <td className="px-4 py-3 text-neutral-600">
                    {Number(mov.quantidade)} {mov.produto.unidade}
                  </td>
                  <td className="px-4 py-3 text-neutral-600">
                    {rotulosMotivo[mov.motivo] ?? mov.motivo}
                  </td>
                  <td className="px-4 py-3 text-neutral-600">
                    {mov.usuario?.nome ?? "—"}
                  </td>
                </tr>
              ))}
              {movimentacoes.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-neutral-400">
                    Nenhuma movimentação registrada ainda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
