"use client";

import { useRouter } from "next/navigation";
import { useState, FormEvent } from "react";

type Cliente = {
  id?: number;
  tipoPessoa: string;
  nomeRazaoSocial: string;
  cpfCnpj: string;
  inscricaoEstadual?: string | null;
  email?: string | null;
  telefone?: string | null;
  endereco?: string | null;
  numero?: string | null;
  complemento?: string | null;
  bairro?: string | null;
  cidade?: string | null;
  uf?: string | null;
  cep?: string | null;
  observacoes?: string | null;
};

const campoBase =
  "w-full rounded-md border border-neutral-300 px-3 py-2 text-sm focus:border-graphite-700 focus:outline-none focus:ring-1 focus:ring-graphite-700";
const rotuloBase = "mb-1 block text-sm text-neutral-600";

export function ClienteForm({ cliente }: { cliente?: Cliente }) {
  const router = useRouter();
  const [dados, setDados] = useState<Cliente>(
    cliente ?? {
      tipoPessoa: "J",
      nomeRazaoSocial: "",
      cpfCnpj: "",
    }
  );
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);

  function atualizar(campo: keyof Cliente, valor: string) {
    setDados((atual) => ({ ...atual, [campo]: valor }));
  }

  async function salvar(evento: FormEvent) {
    evento.preventDefault();
    setErro("");
    setSalvando(true);

    const url = cliente?.id ? `/api/clientes/${cliente.id}` : "/api/clientes";
    const metodo = cliente?.id ? "PUT" : "POST";

    const resposta = await fetch(url, {
      method: metodo,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dados),
    });

    setSalvando(false);

    if (!resposta.ok) {
      const corpo = await resposta.json().catch(() => ({}));
      setErro(corpo.erro ?? "Não foi possível salvar o cliente.");
      return;
    }

    router.push("/clientes");
    router.refresh();
  }

  return (
    <form onSubmit={salvar} className="max-w-2xl space-y-6">
      {erro && (
        <p className="rounded-md bg-red-50 px-4 py-2 text-sm text-red-700">
          {erro}
        </p>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={rotuloBase}>Tipo de pessoa</label>
          <select
            className={campoBase}
            value={dados.tipoPessoa}
            onChange={(e) => atualizar("tipoPessoa", e.target.value)}
          >
            <option value="J">Pessoa jurídica</option>
            <option value="F">Pessoa física</option>
          </select>
        </div>
        <div>
          <label className={rotuloBase}>CPF / CNPJ</label>
          <input
            className={campoBase}
            value={dados.cpfCnpj}
            onChange={(e) => atualizar("cpfCnpj", e.target.value)}
            required
          />
        </div>
      </div>

      <div>
        <label className={rotuloBase}>Nome / razão social</label>
        <input
          className={campoBase}
          value={dados.nomeRazaoSocial}
          onChange={(e) => atualizar("nomeRazaoSocial", e.target.value)}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={rotuloBase}>E-mail</label>
          <input
            className={campoBase}
            type="email"
            value={dados.email ?? ""}
            onChange={(e) => atualizar("email", e.target.value)}
          />
        </div>
        <div>
          <label className={rotuloBase}>Telefone</label>
          <input
            className={campoBase}
            value={dados.telefone ?? ""}
            onChange={(e) => atualizar("telefone", e.target.value)}
          />
        </div>
      </div>

      <div>
        <label className={rotuloBase}>Inscrição estadual</label>
        <input
          className={campoBase}
          value={dados.inscricaoEstadual ?? ""}
          onChange={(e) => atualizar("inscricaoEstadual", e.target.value)}
        />
      </div>

      <fieldset className="rounded-md border border-neutral-200 p-4">
        <legend className="px-1 text-sm text-neutral-500">Endereço</legend>
        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2">
            <label className={rotuloBase}>Rua</label>
            <input
              className={campoBase}
              value={dados.endereco ?? ""}
              onChange={(e) => atualizar("endereco", e.target.value)}
            />
          </div>
          <div>
            <label className={rotuloBase}>Número</label>
            <input
              className={campoBase}
              value={dados.numero ?? ""}
              onChange={(e) => atualizar("numero", e.target.value)}
            />
          </div>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-4">
          <div>
            <label className={rotuloBase}>Bairro</label>
            <input
              className={campoBase}
              value={dados.bairro ?? ""}
              onChange={(e) => atualizar("bairro", e.target.value)}
            />
          </div>
          <div>
            <label className={rotuloBase}>Cidade</label>
            <input
              className={campoBase}
              value={dados.cidade ?? ""}
              onChange={(e) => atualizar("cidade", e.target.value)}
            />
          </div>
          <div>
            <label className={rotuloBase}>UF</label>
            <input
              className={campoBase}
              maxLength={2}
              value={dados.uf ?? ""}
              onChange={(e) => atualizar("uf", e.target.value.toUpperCase())}
            />
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-4">
          <div>
            <label className={rotuloBase}>CEP</label>
            <input
              className={campoBase}
              value={dados.cep ?? ""}
              onChange={(e) => atualizar("cep", e.target.value)}
            />
          </div>
          <div>
            <label className={rotuloBase}>Complemento</label>
            <input
              className={campoBase}
              value={dados.complemento ?? ""}
              onChange={(e) => atualizar("complemento", e.target.value)}
            />
          </div>
        </div>
      </fieldset>

      <div>
        <label className={rotuloBase}>Observações</label>
        <textarea
          className={campoBase}
          rows={3}
          value={dados.observacoes ?? ""}
          onChange={(e) => atualizar("observacoes", e.target.value)}
        />
      </div>

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={salvando}
          className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800 disabled:opacity-50"
        >
          {salvando ? "Salvando..." : "Salvar cliente"}
        </button>
        <button
          type="button"
          onClick={() => router.push("/clientes")}
          className="rounded-md border border-neutral-300 px-4 py-2 text-sm text-neutral-700 hover:border-neutral-400"
        >
          Cancelar
        </button>
      </div>
    </form>
  );
}
