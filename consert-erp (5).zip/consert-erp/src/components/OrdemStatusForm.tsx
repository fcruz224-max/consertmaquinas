"use client";

import { useRouter } from "next/navigation";
import { useState, FormEvent } from "react";

const campoBase =
  "w-full rounded-md border border-neutral-300 px-3 py-2 text-sm focus:border-graphite-700 focus:outline-none focus:ring-1 focus:ring-graphite-700";
const rotuloBase = "mb-1 block text-sm text-neutral-600";

const statusOpcoes = [
  { valor: "aberta", rotulo: "Aberta" },
  { valor: "em_andamento", rotulo: "Em andamento" },
  { valor: "aguardando_peca", rotulo: "Aguardando peça" },
  { valor: "concluida", rotulo: "Concluída" },
  { valor: "cancelada", rotulo: "Cancelada" },
];

export function OrdemStatusForm({
  ordemId,
  statusAtual,
  diagnosticoAtual,
  valorServicoAtual,
}: {
  ordemId: number;
  statusAtual: string;
  diagnosticoAtual: string;
  valorServicoAtual: string;
}) {
  const router = useRouter();
  const [status, setStatus] = useState(statusAtual);
  const [diagnostico, setDiagnostico] = useState(diagnosticoAtual);
  const [valorServico, setValorServico] = useState(valorServicoAtual);
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState("");

  async function salvar(evento: FormEvent) {
    evento.preventDefault();
    setErro("");
    setSalvando(true);

    const resposta = await fetch(`/api/ordens-manutencao/${ordemId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status, diagnostico, valorServico }),
    });

    setSalvando(false);

    if (!resposta.ok) {
      setErro("Não foi possível salvar as alterações.");
      return;
    }

    router.refresh();
  }

  return (
    <form onSubmit={salvar} className="space-y-4 rounded-lg border border-neutral-200 bg-white p-5">
      {erro && <p className="text-sm text-red-600">{erro}</p>}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={rotuloBase}>Status</label>
          <select
            className={campoBase}
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            {statusOpcoes.map((opcao) => (
              <option key={opcao.valor} value={opcao.valor}>
                {opcao.rotulo}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className={rotuloBase}>Valor do serviço (R$)</label>
          <input
            className={campoBase}
            type="number"
            step="0.01"
            value={valorServico}
            onChange={(e) => setValorServico(e.target.value)}
          />
        </div>
      </div>
      <div>
        <label className={rotuloBase}>Diagnóstico</label>
        <textarea
          className={campoBase}
          rows={3}
          value={diagnostico}
          onChange={(e) => setDiagnostico(e.target.value)}
        />
      </div>
      <button
        type="submit"
        disabled={salvando}
        className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800 disabled:opacity-50"
      >
        {salvando ? "Salvando..." : "Salvar alterações"}
      </button>
    </form>
  );
}
