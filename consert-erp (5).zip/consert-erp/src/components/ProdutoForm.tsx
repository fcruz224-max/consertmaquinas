"use client";

import { useRouter } from "next/navigation";
import { useState, FormEvent } from "react";

type Produto = {
  id?: number;
  codigo: string;
  nome: string;
  descricao?: string | null;
  unidade: string;
  ncm?: string | null;
  cfopPadrao?: string | null;
  precoCusto: string | number;
  precoVenda: string | number;
  estoqueAtual: string | number;
  estoqueMinimo: string | number;
  fornecedorId?: string | number | null;
};

type Fornecedor = { id: number; nomeRazaoSocial: string };

const campoBase =
  "w-full rounded-md border border-neutral-300 px-3 py-2 text-sm focus:border-graphite-700 focus:outline-none focus:ring-1 focus:ring-graphite-700";
const rotuloBase = "mb-1 block text-sm text-neutral-600";

export function ProdutoForm({
  produto,
  fornecedores = [],
}: {
  produto?: Produto;
  fornecedores?: Fornecedor[];
}) {
  const router = useRouter();
  const [dados, setDados] = useState<Produto>(
    produto ?? {
      codigo: "",
      nome: "",
      unidade: "UN",
      precoCusto: "0",
      precoVenda: "0",
      estoqueAtual: "0",
      estoqueMinimo: "0",
    }
  );
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);

  function atualizar(campo: keyof Produto, valor: string) {
    setDados((atual) => ({ ...atual, [campo]: valor }));
  }

  async function salvar(evento: FormEvent) {
    evento.preventDefault();
    setErro("");
    setSalvando(true);

    const url = produto?.id ? `/api/produtos/${produto.id}` : "/api/produtos";
    const metodo = produto?.id ? "PUT" : "POST";

    const resposta = await fetch(url, {
      method: metodo,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dados),
    });

    setSalvando(false);

    if (!resposta.ok) {
      const corpo = await resposta.json().catch(() => ({}));
      setErro(corpo.erro ?? "Não foi possível salvar o produto.");
      return;
    }

    router.push("/produtos");
    router.refresh();
  }

  return (
    <form onSubmit={salvar} className="max-w-2xl space-y-6">
      {erro && (
        <p className="rounded-md bg-red-50 px-4 py-2 text-sm text-red-700">
          {erro}
        </p>
      )}

      <div className="grid grid-cols-3 gap-4">
        <div>
          <label className={rotuloBase}>Código</label>
          <input
            className={campoBase}
            value={dados.codigo}
            onChange={(e) => atualizar("codigo", e.target.value)}
            required
          />
        </div>
        <div className="col-span-2">
          <label className={rotuloBase}>Nome</label>
          <input
            className={campoBase}
            value={dados.nome}
            onChange={(e) => atualizar("nome", e.target.value)}
            required
          />
        </div>
      </div>

      <div>
        <label className={rotuloBase}>Descrição</label>
        <textarea
          className={campoBase}
          rows={2}
          value={dados.descricao ?? ""}
          onChange={(e) => atualizar("descricao", e.target.value)}
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <label className={rotuloBase}>Unidade</label>
          <select
            className={campoBase}
            value={dados.unidade}
            onChange={(e) => atualizar("unidade", e.target.value)}
          >
            <option value="UN">Unidade (UN)</option>
            <option value="PC">Peça (PC)</option>
            <option value="KG">Quilo (KG)</option>
            <option value="L">Litro (L)</option>
            <option value="M">Metro (M)</option>
            <option value="CX">Caixa (CX)</option>
          </select>
        </div>
        <div>
          <label className={rotuloBase}>NCM</label>
          <input
            className={campoBase}
            value={dados.ncm ?? ""}
            onChange={(e) => atualizar("ncm", e.target.value)}
            placeholder="Necessário para nota fiscal"
          />
        </div>
        <div>
          <label className={rotuloBase}>CFOP padrão</label>
          <input
            className={campoBase}
            value={dados.cfopPadrao ?? ""}
            onChange={(e) => atualizar("cfopPadrao", e.target.value)}
            placeholder="Necessário para nota fiscal"
          />
        </div>
      </div>

      <div>
        <label className={rotuloBase}>Fornecedor (opcional)</label>
        <select
          className={campoBase}
          value={dados.fornecedorId ?? ""}
          onChange={(e) => atualizar("fornecedorId", e.target.value)}
        >
          <option value="">Nenhum</option>
          {fornecedores.map((f) => (
            <option key={f.id} value={f.id}>
              {f.nomeRazaoSocial}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={rotuloBase}>Preço de custo (R$)</label>
          <input
            className={campoBase}
            type="number"
            step="0.01"
            value={dados.precoCusto}
            onChange={(e) => atualizar("precoCusto", e.target.value)}
          />
        </div>
        <div>
          <label className={rotuloBase}>Preço de venda (R$)</label>
          <input
            className={campoBase}
            type="number"
            step="0.01"
            value={dados.precoVenda}
            onChange={(e) => atualizar("precoVenda", e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={rotuloBase}>Estoque atual</label>
          <input
            className={campoBase}
            type="number"
            step="0.001"
            value={dados.estoqueAtual}
            onChange={(e) => atualizar("estoqueAtual", e.target.value)}
          />
        </div>
        <div>
          <label className={rotuloBase}>Estoque mínimo</label>
          <input
            className={campoBase}
            type="number"
            step="0.001"
            value={dados.estoqueMinimo}
            onChange={(e) => atualizar("estoqueMinimo", e.target.value)}
          />
          <p className="mt-1 text-xs text-neutral-400">
            Abaixo desse valor, o produto aparece como estoque baixo no painel.
          </p>
        </div>
      </div>

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={salvando}
          className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800 disabled:opacity-50"
        >
          {salvando ? "Salvando..." : "Salvar produto"}
        </button>
        <button
          type="button"
          onClick={() => router.push("/produtos")}
          className="rounded-md border border-neutral-300 px-4 py-2 text-sm text-neutral-700 hover:border-neutral-400"
        >
          Cancelar
        </button>
      </div>
    </form>
  );
}
