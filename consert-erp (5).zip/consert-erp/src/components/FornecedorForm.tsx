"use client";

import { useRouter } from "next/navigation";
import { useState, FormEvent } from "react";

type Fornecedor = {
  id?: number;
  nomeRazaoSocial: string;
  cnpj?: string | null;
  telefone?: string | null;
  email?: string | null;
};

const campoBase =
  "w-full rounded-md border border-neutral-300 px-3 py-2 text-sm focus:border-graphite-700 focus:outline-none focus:ring-1 focus:ring-graphite-700";
const rotuloBase = "mb-1 block text-sm text-neutral-600";

export function FornecedorForm({ fornecedor }: { fornecedor?: Fornecedor }) {
  const router = useRouter();
  const [dados, setDados] = useState<Fornecedor>(
    fornecedor ?? { nomeRazaoSocial: "" }
  );
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);

  function atualizar(campo: keyof Fornecedor, valor: string) {
    setDados((atual) => ({ ...atual, [campo]: valor }));
  }

  async function salvar(evento: FormEvent) {
    evento.preventDefault();
    setErro("");
    setSalvando(true);

    const url = fornecedor?.id
      ? `/api/fornecedores/${fornecedor.id}`
      : "/api/fornecedores";
    const metodo = fornecedor?.id ? "PUT" : "POST";

    const resposta = await fetch(url, {
      method: metodo,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dados),
    });

    setSalvando(false);

    if (!resposta.ok) {
      const corpo = await resposta.json().catch(() => ({}));
      setErro(corpo.erro ?? "Não foi possível salvar o fornecedor.");
      return;
    }

    router.push("/fornecedores");
    router.refresh();
  }

  return (
    <form onSubmit={salvar} className="max-w-xl space-y-6">
      {erro && (
        <p className="rounded-md bg-red-50 px-4 py-2 text-sm text-red-700">{erro}</p>
      )}

      <div>
        <label className={rotuloBase}>Nome / razão social</label>
        <input
          className={campoBase}
          value={dados.nomeRazaoSocial}
          onChange={(e) => atualizar("nomeRazaoSocial", e.target.value)}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={rotuloBase}>CNPJ</label>
          <input
            className={campoBase}
            value={dados.cnpj ?? ""}
            onChange={(e) => atualizar("cnpj", e.target.value)}
          />
        </div>
        <div>
          <label className={rotuloBase}>Telefone</label>
          <input
            className={campoBase}
            value={dados.telefone ?? ""}
            onChange={(e) => atualizar("telefone", e.target.value)}
          />
        </div>
      </div>

      <div>
        <label className={rotuloBase}>E-mail</label>
        <input
          className={campoBase}
          type="email"
          value={dados.email ?? ""}
          onChange={(e) => atualizar("email", e.target.value)}
        />
      </div>

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={salvando}
          className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800 disabled:opacity-50"
        >
          {salvando ? "Salvando..." : "Salvar fornecedor"}
        </button>
        <button
          type="button"
          onClick={() => router.push("/fornecedores")}
          className="rounded-md border border-neutral-300 px-4 py-2 text-sm text-neutral-700 hover:border-neutral-400"
        >
          Cancelar
        </button>
      </div>
    </form>
  );
}
