import Link from "next/link";

const links = [
  { href: "/", label: "Painel" },
  { href: "/clientes", label: "Clientes" },
  { href: "/produtos", label: "Estoque" },
  { href: "/fornecedores", label: "Fornecedores" },
  { href: "/movimentacoes", label: "Entradas e saídas" },
  { href: "/ordens-manutencao", label: "Ordens de manutenção" },
  { href: "/notas-fiscais", label: "Notas fiscais" },
];

export function Sidebar() {
  return (
    <aside className="flex h-screen w-60 flex-col justify-between bg-graphite-950 text-neutral-200">
      <div>
        <div className="border-b border-graphite-800 px-5 py-5">
          <p className="text-sm font-medium text-neutral-100">Consert Máquinas</p>
          <p className="text-xs text-neutral-400">Sistema de gestão</p>
        </div>
        <nav className="mt-2 flex flex-col gap-1 px-3">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-md px-3 py-2 text-sm text-neutral-300 transition hover:bg-graphite-800 hover:text-amber-500"
            >
              {link.label}
            </Link>
          ))}
        </nav>
      </div>
      <div className="border-t border-graphite-800 px-5 py-4 text-xs text-neutral-500">
        v0.1 — ambiente interno
      </div>
    </aside>
  );
}
