"use client";

import { useRouter } from "next/navigation";
import { useState, FormEvent } from "react";

type Produto = {
  id: number;
  codigo: string;
  nome: string;
  unidade: string;
  estoqueAtual: string;
};

const campoBase =
  "w-full rounded-md border border-neutral-300 px-3 py-2 text-sm focus:border-graphite-700 focus:outline-none focus:ring-1 focus:ring-graphite-700";
const rotuloBase = "mb-1 block text-sm text-neutral-600";

const motivosPorTipo: Record<string, { valor: string; rotulo: string }[]> = {
  entrada: [
    { valor: "compra", rotulo: "Compra de fornecedor" },
    { valor: "devolucao", rotulo: "Devolução de cliente" },
    { valor: "ajuste", rotulo: "Ajuste de inventário" },
  ],
  saida: [
    { valor: "uso_os", rotulo: "Uso em ordem de manutenção" },
    { valor: "venda", rotulo: "Venda avulsa" },
    { valor: "ajuste", rotulo: "Ajuste de inventário" },
  ],
};

export function MovimentacaoForm({ produtos }: { produtos: Produto[] }) {
  const router = useRouter();
  const [tipo, setTipo] = useState<"entrada" | "saida">("entrada");
  const [produtoId, setProdutoId] = useState(produtos[0]?.id ?? "");
  const [quantidade, setQuantidade] = useState("1");
  const [motivo, setMotivo] = useState(motivosPorTipo.entrada[0].valor);
  const [observacoes, setObservacoes] = useState("");
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);

  const produtoSelecionado = produtos.find((p) => p.id === Number(produtoId));

  async function salvar(evento: FormEvent) {
    evento.preventDefault();
    setErro("");
    setSalvando(true);

    const resposta = await fetch("/api/movimentacoes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tipo, produtoId, quantidade, motivo, observacoes }),
    });

    setSalvando(false);

    if (!resposta.ok) {
      const corpo = await resposta.json().catch(() => ({}));
      setErro(corpo.erro ?? "Não foi possível registrar a movimentação.");
      return;
    }

    router.push("/movimentacoes");
    router.refresh();
  }

  return (
    <form onSubmit={salvar} className="max-w-xl space-y-6">
      {erro && (
        <p className="rounded-md bg-red-50 px-4 py-2 text-sm text-red-700">{erro}</p>
      )}

      <div>
        <label className={rotuloBase}>Tipo de movimentação</label>
        <div className="flex gap-3">
          <button
            type="button"
            onClick={() => {
              setTipo("entrada");
              setMotivo(motivosPorTipo.entrada[0].valor);
            }}
            className={`flex-1 rounded-md border px-4 py-2 text-sm font-medium transition ${
              tipo === "entrada"
                ? "border-graphite-950 bg-graphite-950 text-white"
                : "border-neutral-300 text-neutral-700"
            }`}
          >
            Entrada
          </button>
          <button
            type="button"
            onClick={() => {
              setTipo("saida");
              setMotivo(motivosPorTipo.saida[0].valor);
            }}
            className={`flex-1 rounded-md border px-4 py-2 text-sm font-medium transition ${
              tipo === "saida"
                ? "border-graphite-950 bg-graphite-950 text-white"
                : "border-neutral-300 text-neutral-700"
            }`}
          >
            Saída
          </button>
        </div>
      </div>

      <div>
        <label className={rotuloBase}>Produto</label>
        <select
          className={campoBase}
          value={produtoId}
          onChange={(e) => setProdutoId(e.target.value)}
        >
          {produtos.map((produto) => (
            <option key={produto.id} value={produto.id}>
              {produto.codigo} — {produto.nome}
            </option>
          ))}
        </select>
        {produtoSelecionado && (
          <p className="mt-1 text-xs text-neutral-400">
            Estoque atual: {produtoSelecionado.estoqueAtual} {produtoSelecionado.unidade}
          </p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={rotuloBase}>Quantidade</label>
          <input
            className={campoBase}
            type="number"
            step="0.001"
            min="0.001"
            value={quantidade}
            onChange={(e) => setQuantidade(e.target.value)}
            required
          />
        </div>
        <div>
          <label className={rotuloBase}>Motivo</label>
          <select
            className={campoBase}
            value={motivo}
            onChange={(e) => setMotivo(e.target.value)}
          >
            {motivosPorTipo[tipo].map((opcao) => (
              <option key={opcao.valor} value={opcao.valor}>
                {opcao.rotulo}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label className={rotuloBase}>Observações</label>
        <textarea
          className={campoBase}
          rows={2}
          value={observacoes}
          onChange={(e) => setObservacoes(e.target.value)}
        />
      </div>

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={salvando || produtos.length === 0}
          className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800 disabled:opacity-50"
        >
          {salvando ? "Registrando..." : "Registrar movimentação"}
        </button>
        <button
          type="button"
          onClick={() => router.push("/movimentacoes")}
          className="rounded-md border border-neutral-300 px-4 py-2 text-sm text-neutral-700 hover:border-neutral-400"
        >
          Cancelar
        </button>
      </div>
    </form>
  );
}
