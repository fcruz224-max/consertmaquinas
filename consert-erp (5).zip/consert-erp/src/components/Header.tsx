import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { SignOutButton } from "@/components/SignOutButton";

export async function Header({ title }: { title: string }) {
  const session = await getServerSession(authOptions);

  return (
    <header className="flex items-center justify-between border-b border-neutral-200 bg-white px-8 py-4">
      <h1 className="text-lg font-medium text-neutral-900">{title}</h1>
      <div className="flex items-center gap-4">
        <div className="text-right">
          <p className="text-sm text-neutral-800">{session?.user?.name}</p>
          <p className="text-xs text-neutral-500">{session?.user?.email}</p>
        </div>
        <SignOutButton />
      </div>
    </header>
  );
}
