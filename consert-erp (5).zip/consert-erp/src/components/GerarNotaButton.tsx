"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function GerarNotaButton({ ordemId }: { ordemId: number }) {
  const router = useRouter();
  const [erro, setErro] = useState("");
  const [gerando, setGerando] = useState(false);

  async function gerar() {
    setGerando(true);
    setErro("");

    const resposta = await fetch("/api/notas-fiscais", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ordemManutencaoId: ordemId }),
    });
    const corpo = await resposta.json().catch(() => ({}));

    setGerando(false);

    if (!resposta.ok) {
      setErro(corpo.erro ?? "Não foi possível gerar a nota fiscal.");
      return;
    }

    router.push(`/notas-fiscais/${corpo.id}`);
  }

  return (
    <div>
      <button
        onClick={gerar}
        disabled={gerando}
        className="rounded-md bg-amber-500 px-4 py-2 text-sm font-medium text-graphite-950 transition hover:bg-amber-600 disabled:opacity-50"
      >
        {gerando ? "Gerando..." : "Gerar nota fiscal"}
      </button>
      {erro && <p className="mt-2 text-sm text-red-600">{erro}</p>}
    </div>
  );
}
