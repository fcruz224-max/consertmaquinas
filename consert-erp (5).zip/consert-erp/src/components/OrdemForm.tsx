"use client";

import { useRouter } from "next/navigation";
import { useState, FormEvent } from "react";

type Cliente = { id: number; nomeRazaoSocial: string };
type Tecnico = { id: number; nome: string };

const campoBase =
  "w-full rounded-md border border-neutral-300 px-3 py-2 text-sm focus:border-graphite-700 focus:outline-none focus:ring-1 focus:ring-graphite-700";
const rotuloBase = "mb-1 block text-sm text-neutral-600";

export function OrdemForm({
  clientes,
  tecnicos,
}: {
  clientes: Cliente[];
  tecnicos: Tecnico[];
}) {
  const router = useRouter();
  const [clienteId, setClienteId] = useState(clientes[0]?.id ?? "");
  const [equipamento, setEquipamento] = useState("");
  const [numeroSerie, setNumeroSerie] = useState("");
  const [descricaoProblema, setDescricaoProblema] = useState("");
  const [tecnicoId, setTecnicoId] = useState("");
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);

  async function salvar(evento: FormEvent) {
    evento.preventDefault();
    setErro("");
    setSalvando(true);

    const resposta = await fetch("/api/ordens-manutencao", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        clienteId,
        equipamento,
        numeroSerie,
        descricaoProblema,
        tecnicoId: tecnicoId || null,
      }),
    });

    setSalvando(false);

    if (!resposta.ok) {
      const corpo = await resposta.json().catch(() => ({}));
      setErro(corpo.erro ?? "Não foi possível abrir a ordem de manutenção.");
      return;
    }

    const ordem = await resposta.json();
    router.push(`/ordens-manutencao/${ordem.id}`);
    router.refresh();
  }

  return (
    <form onSubmit={salvar} className="max-w-xl space-y-6">
      {erro && (
        <p className="rounded-md bg-red-50 px-4 py-2 text-sm text-red-700">{erro}</p>
      )}

      <div>
        <label className={rotuloBase}>Cliente</label>
        <select
          className={campoBase}
          value={clienteId}
          onChange={(e) => setClienteId(e.target.value)}
          required
        >
          {clientes.map((c) => (
            <option key={c.id} value={c.id}>
              {c.nomeRazaoSocial}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={rotuloBase}>Equipamento</label>
          <input
            className={campoBase}
            value={equipamento}
            onChange={(e) => setEquipamento(e.target.value)}
            placeholder="Ex: Torno mecânico"
            required
          />
        </div>
        <div>
          <label className={rotuloBase}>Número de série</label>
          <input
            className={campoBase}
            value={numeroSerie}
            onChange={(e) => setNumeroSerie(e.target.value)}
          />
        </div>
      </div>

      <div>
        <label className={rotuloBase}>Descrição do problema</label>
        <textarea
          className={campoBase}
          rows={3}
          value={descricaoProblema}
          onChange={(e) => setDescricaoProblema(e.target.value)}
          required
        />
      </div>

      <div>
        <label className={rotuloBase}>Técnico responsável (opcional)</label>
        <select
          className={campoBase}
          value={tecnicoId}
          onChange={(e) => setTecnicoId(e.target.value)}
        >
          <option value="">A definir</option>
          {tecnicos.map((t) => (
            <option key={t.id} value={t.id}>
              {t.nome}
            </option>
          ))}
        </select>
      </div>

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={salvando || clientes.length === 0}
          className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800 disabled:opacity-50"
        >
          {salvando ? "Abrindo..." : "Abrir ordem de manutenção"}
        </button>
        <button
          type="button"
          onClick={() => router.push("/ordens-manutencao")}
          className="rounded-md border border-neutral-300 px-4 py-2 text-sm text-neutral-700 hover:border-neutral-400"
        >
          Cancelar
        </button>
      </div>
      {clientes.length === 0 && (
        <p className="text-sm text-amber-600">
          Cadastre ao menos um cliente antes de abrir uma ordem de manutenção.
        </p>
      )}
    </form>
  );
}
