"use client";

import { signOut } from "next-auth/react";

export function SignOutButton() {
  return (
    <button
      onClick={() => signOut({ callbackUrl: "/login" })}
      className="rounded-md border border-neutral-300 px-3 py-1.5 text-sm text-neutral-700 transition hover:border-neutral-400"
    >
      Sair
    </button>
  );
}
