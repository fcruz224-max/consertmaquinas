"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function EnviarNotaButton({ notaId }: { notaId: number }) {
  const router = useRouter();
  const [mensagem, setMensagem] = useState("");
  const [enviando, setEnviando] = useState(false);

  async function enviar() {
    setEnviando(true);
    setMensagem("");

    const resposta = await fetch(`/api/notas-fiscais/${notaId}/enviar`, {
      method: "POST",
    });
    const corpo = await resposta.json().catch(() => ({}));

    setEnviando(false);

    if (!resposta.ok) {
      setMensagem(corpo.erro ?? "Não foi possível enviar a nota.");
      return;
    }

    router.refresh();
  }

  return (
    <div>
      <button
        onClick={enviar}
        disabled={enviando}
        className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800 disabled:opacity-50"
      >
        {enviando ? "Enviando..." : "Enviar para o provedor de NF-e"}
      </button>
      {mensagem && (
        <p className="mt-2 max-w-md text-sm text-amber-600">{mensagem}</p>
      )}
    </div>
  );
}
