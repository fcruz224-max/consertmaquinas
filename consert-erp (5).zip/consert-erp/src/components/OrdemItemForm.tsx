"use client";

import { useRouter } from "next/navigation";
import { useState, FormEvent } from "react";

type Produto = { id: number; codigo: string; nome: string; unidade: string; estoqueAtual: string };

const campoBase =
  "w-full rounded-md border border-neutral-300 px-3 py-2 text-sm focus:border-graphite-700 focus:outline-none focus:ring-1 focus:ring-graphite-700";

export function OrdemItemForm({
  ordemId,
  produtos,
}: {
  ordemId: number;
  produtos: Produto[];
}) {
  const router = useRouter();
  const [produtoId, setProdutoId] = useState(produtos[0]?.id ?? "");
  const [quantidade, setQuantidade] = useState("1");
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);

  async function adicionar(evento: FormEvent) {
    evento.preventDefault();
    setErro("");
    setSalvando(true);

    const resposta = await fetch(`/api/ordens-manutencao/${ordemId}/itens`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ produtoId, quantidade }),
    });

    setSalvando(false);

    if (!resposta.ok) {
      const corpo = await resposta.json().catch(() => ({}));
      setErro(corpo.erro ?? "Não foi possível adicionar a peça.");
      return;
    }

    setQuantidade("1");
    router.refresh();
  }

  if (produtos.length === 0) {
    return (
      <p className="text-sm text-neutral-400">
        Nenhum produto com estoque disponível no momento.
      </p>
    );
  }

  return (
    <form onSubmit={adicionar} className="flex flex-wrap items-end gap-3">
      {erro && <p className="w-full text-sm text-red-600">{erro}</p>}
      <div className="min-w-[240px] flex-1">
        <select
          className={campoBase}
          value={produtoId}
          onChange={(e) => setProdutoId(e.target.value)}
        >
          {produtos.map((p) => (
            <option key={p.id} value={p.id}>
              {p.codigo} — {p.nome} (disponível: {p.estoqueAtual} {p.unidade})
            </option>
          ))}
        </select>
      </div>
      <div className="w-28">
        <input
          className={campoBase}
          type="number"
          step="0.001"
          min="0.001"
          value={quantidade}
          onChange={(e) => setQuantidade(e.target.value)}
        />
      </div>
      <button
        type="submit"
        disabled={salvando}
        className="rounded-md bg-graphite-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-graphite-800 disabled:opacity-50"
      >
        {salvando ? "Adicionando..." : "Adicionar peça"}
      </button>
    </form>
  );
}
