import { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import { prisma } from "@/lib/prisma";

const allowedDomain = process.env.ALLOWED_GOOGLE_DOMAIN;

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      authorization: {
        params: {
          // Sugere ao Google já filtrar contas do domínio da empresa na tela de login
          hd: allowedDomain,
        },
      },
    }),
  ],
  session: {
    strategy: "jwt",
  },
  pages: {
    signIn: "/login",
  },
  callbacks: {
    // Bloqueia login de qualquer conta fora do domínio da empresa,
    // mesmo que a pessoa tente escolher outra conta Google na tela de login.
    async signIn({ user, profile }) {
      const email = user.email ?? "";
      if (allowedDomain && !email.endsWith(`@${allowedDomain}`)) {
        return false;
      }

      // Garante que o usuário existe na nossa tabela local, com papel padrão "tecnico"
      // (o admin pode depois trocar o papel diretamente no banco ou numa tela de gestão de usuários).
      const googleId = (profile as any)?.sub ?? email;
      await prisma.usuario.upsert({
        where: { email },
        update: { nome: user.name ?? email, googleId },
        create: {
          email,
          nome: user.name ?? email,
          googleId,
          papel: "tecnico",
        },
      });

      return true;
    },
    async session({ session }) {
      if (session.user?.email) {
        const usuario = await prisma.usuario.findUnique({
          where: { email: session.user.email },
        });
        if (usuario) {
          (session.user as any).id = usuario.id;
          (session.user as any).papel = usuario.papel;
          (session.user as any).ativo = usuario.ativo;
        }
      }
      return session;
    },
  },
};
