export { default } from "next-auth/middleware";

export const config = {
  // Protege todas as rotas, exceto login, arquivos estáticos e a própria API do NextAuth
  matcher: ["/((?!api/auth|login|_next/static|_next/image|favicon.ico).*)"],
};
