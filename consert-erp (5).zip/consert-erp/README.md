# Consert Máquinas — ERP

Sistema de gestão interno: clientes, estoque, entradas/saídas, ordens de manutenção e notas fiscais.

Este pacote já vem com **todos os módulos principais funcionando de ponta a ponta**.

## 1. O que já está pronto

- Login com Google Workspace (só entra quem tem e-mail do domínio da empresa)
- Banco de dados completo (`prisma/schema.prisma`) com todas as tabelas: clientes, produtos/estoque, movimentações, ordens de manutenção, notas fiscais
- Painel inicial com indicadores (clientes ativos, produtos, OS em aberto, estoque baixo)
- CRUD completo de **Clientes**
- CRUD completo de **Produtos/Estoque**, com aviso visual de estoque abaixo do mínimo
- **Entradas e saídas de estoque**, com atualização automática do saldo do produto
- **Ordens de manutenção**: abertura, adição de peças (com baixa automática no estoque), atualização de status/diagnóstico/valor do serviço
- **Notas fiscais**: geração de rascunho automático a partir de uma OS concluída (soma peças + serviço). O envio para a SEFAZ fica pronto para ligar assim que vocês contratarem um provedor de NF-e — veja a seção 5

## 2. Passo a passo para rodar

### 2.1 Banco de dados
Crie um banco PostgreSQL gratuito em [neon.tech](https://neon.tech) ou use o Vercel Postgres. Copie a connection string.

### 2.2 Login com Google
1. Acesse [console.cloud.google.com](https://console.cloud.google.com/apis/credentials)
2. Crie um projeto (ex: "Consert ERP")
3. Configure a "Tela de consentimento OAuth" com o seu domínio Google Workspace
4. Crie uma credencial "ID do cliente OAuth" tipo **Aplicativo da Web**
5. Em "URIs de redirecionamento autorizados", adicione:
   - `http://localhost:3000/api/auth/callback/google` (para testar local)
   - `https://SEU-DOMINIO.vercel.app/api/auth/callback/google` (depois do deploy)
6. Copie o Client ID e o Client Secret

### 2.3 Configurar variáveis de ambiente
```bash
cp .env.example .env
```
Preencha `DATABASE_URL`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `ALLOWED_GOOGLE_DOMAIN` (o domínio de e-mail da empresa, ex: `consertmaquinas.com.br`) e gere um `NEXTAUTH_SECRET` com:
```bash
openssl rand -base64 32
```

### 2.4 Instalar e rodar localmente
```bash
npm install
npx prisma migrate dev --name inicial
npm run dev
```
Acesse `http://localhost:3000`.

## 3. Publicar no GitHub e na Vercel

```bash
git init
git add .
git commit -m "Primeira versão do ERP"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/consert-erp.git
git push -u origin main
```

Depois:
1. Acesse [vercel.com](https://vercel.com) e faça login com o GitHub
2. Clique em "Add New Project" e escolha o repositório `consert-erp`
3. Em "Environment Variables", adicione as mesmas variáveis do seu `.env` (troque `NEXTAUTH_URL` pela URL final da Vercel)
4. Clique em "Deploy"

A cada `git push`, a Vercel publica a nova versão automaticamente.

## 4. Fluxo completo já implementado

1. Cadastre clientes e produtos
2. Registre entradas de estoque (compras) em **Entradas e saídas**
3. Abra uma **ordem de manutenção**, adicione as peças usadas (o estoque é debitado sozinho) e preencha o diagnóstico/valor do serviço
4. Marque a ordem como **concluída**
5. Na tela da ordem, clique em **Gerar nota fiscal** — cria um rascunho somando peças + serviço
6. Quando tiver certificado digital e provedor de NF-e contratados, configure as variáveis `NFE_PROVIDER_API_URL` e `NFE_PROVIDER_API_TOKEN` e complete a chamada real dentro de `src/app/api/notas-fiscais/[id]/enviar/route.ts` (o local já está comentado com um exemplo)

## 5. Pendências que dependem de você / do contador

- Certificado digital e-CNPJ + Inscrição Estadual/Municipal
- Contratação de um provedor de NF-e (Focus NFe, PlugNotas etc.)
- Cadastro de usuários com papel "admin" (por padrão, todo novo login vira "tecnico" — troque o papel direto no banco pela Prisma Studio: `npm run prisma:studio`)
- Backups automáticos e relatórios via Google Apps Script (ainda não incluído nesta versão)

Veja o arquivo `ARQUITETURA.md` (enviado anteriormente) para o desenho geral do sistema.
