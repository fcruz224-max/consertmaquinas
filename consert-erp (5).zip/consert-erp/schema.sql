-- ============================================================
-- ERP CONSERT MÁQUINAS — Schema do banco de dados (PostgreSQL)
-- ============================================================

-- ---------- USUÁRIOS (login via Google Workspace) ----------
CREATE TABLE usuarios (
    id              SERIAL PRIMARY KEY,
    google_id       VARCHAR(255) UNIQUE NOT NULL,
    nome            VARCHAR(150) NOT NULL,
    email           VARCHAR(150) UNIQUE NOT NULL,
    papel           VARCHAR(30) NOT NULL DEFAULT 'tecnico'
                    CHECK (papel IN ('admin', 'financeiro', 'estoque', 'tecnico')),
    ativo           BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em       TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------- CLIENTES ----------
CREATE TABLE clientes (
    id                  SERIAL PRIMARY KEY,
    tipo_pessoa         CHAR(1) NOT NULL CHECK (tipo_pessoa IN ('F', 'J')), -- Física ou Jurídica
    nome_razao_social   VARCHAR(200) NOT NULL,
    cpf_cnpj            VARCHAR(18) UNIQUE NOT NULL,
    inscricao_estadual  VARCHAR(20),
    email               VARCHAR(150),
    telefone            VARCHAR(20),
    endereco            VARCHAR(200),
    numero              VARCHAR(10),
    complemento         VARCHAR(100),
    bairro              VARCHAR(100),
    cidade              VARCHAR(100),
    uf                  CHAR(2),
    cep                 VARCHAR(10),
    observacoes         TEXT,
    ativo               BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em           TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------- FORNECEDORES ----------
CREATE TABLE fornecedores (
    id                  SERIAL PRIMARY KEY,
    nome_razao_social   VARCHAR(200) NOT NULL,
    cnpj                VARCHAR(18) UNIQUE,
    telefone            VARCHAR(20),
    email               VARCHAR(150),
    ativo               BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em           TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------- PRODUTOS / ESTOQUE ----------
CREATE TABLE produtos (
    id                  SERIAL PRIMARY KEY,
    codigo              VARCHAR(30) UNIQUE NOT NULL,
    nome                VARCHAR(200) NOT NULL,
    descricao           TEXT,
    unidade             VARCHAR(10) NOT NULL DEFAULT 'UN', -- UN, PC, KG, etc.
    ncm                 VARCHAR(10),           -- necessário para nota fiscal
    cfop_padrao         VARCHAR(10),           -- necessário para nota fiscal
    preco_custo         NUMERIC(12,2) NOT NULL DEFAULT 0,
    preco_venda         NUMERIC(12,2) NOT NULL DEFAULT 0,
    estoque_atual       NUMERIC(12,3) NOT NULL DEFAULT 0,
    estoque_minimo      NUMERIC(12,3) NOT NULL DEFAULT 0,
    fornecedor_id       INTEGER REFERENCES fornecedores(id),
    ativo               BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em           TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------- MOVIMENTAÇÕES DE ESTOQUE (entradas/saídas) ----------
CREATE TABLE movimentacoes_estoque (
    id                  SERIAL PRIMARY KEY,
    produto_id          INTEGER NOT NULL REFERENCES produtos(id),
    tipo                VARCHAR(10) NOT NULL CHECK (tipo IN ('entrada', 'saida')),
    quantidade          NUMERIC(12,3) NOT NULL CHECK (quantidade > 0),
    motivo              VARCHAR(50) NOT NULL, -- compra, ajuste, uso_os, devolucao, venda
    ordem_manutencao_id INTEGER,               -- referência opcional (definida abaixo)
    nota_fiscal_id      INTEGER,               -- referência opcional (definida abaixo)
    usuario_id          INTEGER REFERENCES usuarios(id),
    observacoes         TEXT,
    criado_em           TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------- ORDENS DE MANUTENÇÃO ----------
CREATE TABLE ordens_manutencao (
    id                  SERIAL PRIMARY KEY,
    numero              VARCHAR(20) UNIQUE NOT NULL,
    cliente_id          INTEGER NOT NULL REFERENCES clientes(id),
    equipamento         VARCHAR(200) NOT NULL,
    numero_serie        VARCHAR(100),
    descricao_problema  TEXT NOT NULL,
    diagnostico         TEXT,
    tecnico_id          INTEGER REFERENCES usuarios(id),
    status              VARCHAR(20) NOT NULL DEFAULT 'aberta'
                        CHECK (status IN ('aberta', 'em_andamento', 'aguardando_peca', 'concluida', 'cancelada')),
    valor_servico        NUMERIC(12,2) NOT NULL DEFAULT 0,
    data_abertura        TIMESTAMP NOT NULL DEFAULT NOW(),
    data_conclusao        TIMESTAMP,
    observacoes         TEXT
);

-- Peças/produtos usados em cada ordem de manutenção
CREATE TABLE ordem_manutencao_itens (
    id                  SERIAL PRIMARY KEY,
    ordem_manutencao_id INTEGER NOT NULL REFERENCES ordens_manutencao(id),
    produto_id          INTEGER NOT NULL REFERENCES produtos(id),
    quantidade          NUMERIC(12,3) NOT NULL CHECK (quantidade > 0),
    valor_unitario      NUMERIC(12,2) NOT NULL
);

-- ---------- NOTAS FISCAIS ----------
CREATE TABLE notas_fiscais (
    id                  SERIAL PRIMARY KEY,
    tipo                VARCHAR(10) NOT NULL CHECK (tipo IN ('nfe', 'nfse')), -- produto ou serviço
    numero              VARCHAR(20),
    serie               VARCHAR(10),
    chave_acesso        VARCHAR(50) UNIQUE,
    cliente_id          INTEGER NOT NULL REFERENCES clientes(id),
    ordem_manutencao_id INTEGER REFERENCES ordens_manutencao(id), -- se originada de uma OS
    status              VARCHAR(20) NOT NULL DEFAULT 'rascunho'
                        CHECK (status IN ('rascunho', 'enviada', 'autorizada', 'cancelada', 'rejeitada')),
    valor_total         NUMERIC(12,2) NOT NULL DEFAULT 0,
    provedor_id_externo VARCHAR(100), -- id da nota no provedor (Focus NFe, etc.)
    url_xml             VARCHAR(300),
    url_danfe           VARCHAR(300),
    data_emissao        TIMESTAMP,
    criado_em           TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE nota_fiscal_itens (
    id                  SERIAL PRIMARY KEY,
    nota_fiscal_id      INTEGER NOT NULL REFERENCES notas_fiscais(id),
    produto_id          INTEGER REFERENCES produtos(id), -- pode ser nulo se for item de serviço avulso
    descricao           VARCHAR(200) NOT NULL,
    ncm                 VARCHAR(10),
    cfop                VARCHAR(10),
    quantidade          NUMERIC(12,3) NOT NULL DEFAULT 1,
    valor_unitario      NUMERIC(12,2) NOT NULL,
    valor_total         NUMERIC(12,2) NOT NULL
);

-- ---------- LOG DE AUDITORIA (segurança) ----------
CREATE TABLE logs_auditoria (
    id              SERIAL PRIMARY KEY,
    usuario_id      INTEGER REFERENCES usuarios(id),
    acao            VARCHAR(50) NOT NULL,   -- ex: "editou_produto", "cancelou_nota"
    tabela_afetada  VARCHAR(50),
    registro_id     INTEGER,
    detalhes        JSONB,
    criado_em       TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Agora que as tabelas existem, criamos as referências cruzadas pendentes:
ALTER TABLE movimentacoes_estoque
    ADD CONSTRAINT fk_mov_os FOREIGN KEY (ordem_manutencao_id) REFERENCES ordens_manutencao(id),
    ADD CONSTRAINT fk_mov_nf FOREIGN KEY (nota_fiscal_id) REFERENCES notas_fiscais(id);

-- ---------- ÍNDICES ÚTEIS ----------
CREATE INDEX idx_produtos_codigo ON produtos(codigo);
CREATE INDEX idx_clientes_cpfcnpj ON clientes(cpf_cnpj);
CREATE INDEX idx_os_status ON ordens_manutencao(status);
CREATE INDEX idx_nf_status ON notas_fiscais(status);
CREATE INDEX idx_mov_produto ON movimentacoes_estoque(produto_id);
